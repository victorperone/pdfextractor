"""PP-OCRv6 compatibility smoke test — Phase 1.

Confirms that v6 models initialize and run offline on CPU,
without any network download attempts.

Usage:
    # Quick check (synthetic image):
    python scripts/eval_v6/smoke_test_v6.py \\
        --cache-home ~/.cache/pdfextractor/paddlex-v6-eval

    # With a real document (recommended — uses the production venv):
    python scripts/eval_v6/smoke_test_v6.py \\
        --cache-home ~/.cache/pdfextractor/paddlex-v6-eval \\
        --pdf corpus/Document_AI_V2.pdf

    # On Windows (PowerShell):
    python scripts\\eval_v6\\smoke_test_v6.py `
        --cache-home "$env:USERPROFILE\\.cache\\pdfextractor\\paddlex-v6-eval" `
        --pdf corpus\\Document_AI_V2.pdf

Note: when --pdf is provided, the synthetic image test is skipped
to avoid loading the models twice into memory.
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path


def _add_src() -> None:
    src = Path(__file__).parent.parent.parent / "src"
    if str(src) not in sys.path:
        sys.path.insert(0, str(src))


def check_models(cache_home: str, profile: str) -> bool:
    _add_src()
    from structured_pdf_text.ocr.models import get_profile

    p = get_profile(profile)
    root = Path(cache_home) / "official_models"
    missing = [
        name for name in [p.doc_orientation, p.textline_orientation, p.detection, p.recognition]
        if not (root / name).exists()
    ]
    if missing:
        print("[FAIL] Modelos ausentes:")
        for m in missing:
            print(f"  {root / m}")
        return False
    print(f"[OK] Todos os modelos encontrados em {root}")
    return True


def test_image(cache_home: str, profile: str) -> bool:
    """Load PaddleOCR directly and run inference on a synthetic image."""
    _add_src()
    from structured_pdf_text.ocr.models import get_profile
    from structured_pdf_text.ocr.runtime_policy import resolve_paddle_runtime_policy

    import numpy as np
    from paddleocr import PaddleOCR

    p = get_profile(profile)
    root = Path(cache_home) / "official_models"
    kwargs = {
        "doc_orientation_classify_model_dir": str(root / p.doc_orientation),
        "doc_orientation_classify_model_name": p.doc_orientation,
        "textline_orientation_model_dir": str(root / p.textline_orientation),
        "textline_orientation_model_name": p.textline_orientation,
        "text_detection_model_dir": str(root / p.detection),
        "text_detection_model_name": p.detection,
        "text_recognition_model_dir": str(root / p.recognition),
        "text_recognition_model_name": p.recognition,
        "use_doc_orientation_classify": True,
        "use_doc_unwarping": True,
        "use_textline_orientation": True,
        "enable_mkldnn": resolve_paddle_runtime_policy().enable_mkldnn,
        "device": "cpu",
    }

    t0 = time.perf_counter()
    ocr = PaddleOCR(**kwargs)
    t1 = time.perf_counter()
    img = np.ones((200, 200, 3), dtype=np.uint8) * 240
    list(ocr.predict(input=img))
    t2 = time.perf_counter()
    print(f"[OK] Init: {(t1-t0)*1000:.0f}ms | Inferência: {(t2-t1)*1000:.0f}ms")
    return True


def test_pdf(pdf: Path, cache_home: str, profile: str) -> bool:
    """Extract the PDF via PdfTextExtractor with the v6 profile."""
    _add_src()
    os.environ["PADDLE_PDX_CACHE_HOME"] = str(Path(cache_home).expanduser().resolve())

    from structured_pdf_text import PdfTextExtractor
    from structured_pdf_text.config import ExtractorConfig, ExtractionMode

    t0 = time.perf_counter()
    # language=profile is the Python-API equivalent of CLI --ocr-model-profile
    doc = PdfTextExtractor(ExtractorConfig(mode=ExtractionMode.BALANCED, language=profile)).extract(pdf)
    elapsed = time.perf_counter() - t0
    chars = sum(len(p.reading_text or "") for p in doc.pages)
    print(f"[OK] {len(doc.pages)} páginas | {chars:,} chars | {elapsed:.1f}s | {doc.diagnostics.status.value}")
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache-home", default=str(Path.home() / ".cache/pdfextractor/paddlex-v6-eval"))
    ap.add_argument("--profile", default="pt-v6-medium", choices=["pt-v6-medium", "pt-v6-small"])
    ap.add_argument("--pdf", type=Path, default=None, help="PDF real para teste (recomendado)")
    args = ap.parse_args()

    cache_home = str(Path(args.cache_home).expanduser().resolve())
    os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"
    os.environ["PADDLE_PDX_CACHE_HOME"] = cache_home

    print(f"Perfil : {args.profile}")
    print(f"Cache  : {cache_home}")

    if not check_models(cache_home, args.profile):
        return 1

    if args.pdf:
        # PDF provided: skip synthetic image to avoid loading models twice
        if not args.pdf.exists():
            print(f"[FAIL] PDF não encontrado: {args.pdf}")
            return 1
        print(f"Testando com {args.pdf.name} (modo balanced, perfil {args.profile})...")
        if not test_pdf(args.pdf, cache_home, args.profile):
            return 1
    else:
        # No PDF: use synthetic image as a quick check
        print("Testando com imagem sintética...")
        if not test_image(cache_home, args.profile):
            return 1

    print("\n[PASS] Smoke test OK — modelos v6 funcionando offline em CPU.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
